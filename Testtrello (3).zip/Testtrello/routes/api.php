<?php

use App\Http\Controllers\CardController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });


Route::resource('column',ColumnController::class)->only(['index','store','show','update','destroy']);
Route::post('card/',[CardController::class,'store']);
Route::post('card/addcardColumn',[CardController::class,'addCardColumn']);
Route::post('card/edit/{id}',[CardController::class,'editCard']);
Route::post('card/update/{id}',[CardController::class,'updateCard']);
Route::delete('card/delete/{id}',[CardController::class,'deleteCard']);

Route::post('card/updateAll', [CardController::class,'updateTasksOrder']);

