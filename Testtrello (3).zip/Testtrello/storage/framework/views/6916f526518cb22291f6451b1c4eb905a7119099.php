<?php $__env->startSection('content'); ?>


<div class="container">
    <Example-Component></Example-Component>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MY_DATA\new\htdocs\Ahsihs\Testtrello\resources\views/home.blade.php ENDPATH**/ ?>