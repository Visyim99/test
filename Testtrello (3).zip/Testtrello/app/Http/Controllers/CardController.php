<?php

namespace App\Http\Controllers;

use App\Card;
use Illuminate\Http\Request;

class CardController extends Controller
{
    //
    public function store(Request $request)
    {
        $Column = Card::create($request->all());
        return response()->json([
            'message'=>'Column Created Successfully!!',
            'Column'=>$Column
        ]);
    }


    public function updateTasksOrder(Request $request)
    {
        
        $this->validate($request, [
            'cards.*.order' => 'required|numeric',
        ]);

        $cards = Card::all();
        foreach ($cards as $card) {
            $id = $card->id;
            
            foreach ($request->cards as $cardsNew) {
                if ($cardsNew['id'] == $id) {
                    $card->order =  $cardsNew['order'];
                    $card->update();
                }
            }
        }

        return response('Updated Successfully.', 200);
    }

    public function addCardColumn (Request $request){
       

        $card = Card::find($request->id);
        $card->column_id = $request->column_id;
        $card->update();
    }

    public function editCard($id){
        if($id){
            $card = Card::find($id);
            return response()->json([
                'card'=>$card
            ]);
        }
    }

    public function updateCard(Request $request){

            $card = Card::find($request->card_id);
            $card->title = $request->title;
            $card->description = $request->description;
            $card->update();

            return response()->json([
                'card'=>$card
            ]);
        
    }


    public function deleteCard($id){

        $card = Card::find($id);
        $card->delete();

        return response()->json([
            'message'=>'delete sucess fully'
        ]);
    
}
}
