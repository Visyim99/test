<?php

namespace App\Http\Controllers;

use App\Card;
use Illuminate\Http\Request;
use App\Column;

class ColumnController extends Controller
{
    //

    public function index()
    {

        $Column = Column::with('card')->get();
        return response()->json($Column);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $Column = Column::create($request->post());
        return response()->json([
            'message' => 'Column Created Successfully!!',
            'Column' => $Column
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Column  $Column
     * @return \Illuminate\Http\Response
     */
    public function show(Column $Column)
    {
        return response()->json($Column);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Column  $Column
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Column $Column)
    {
        $Column->fill($request->post())->save();
        return response()->json([
            'message' => 'Column Updated Successfully!!',
            'Column' => $Column
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Column  $Column
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $Column = Column::find($id);
        $card = Card::where('column_id', $id)->get();
        if ($card) {
            foreach ($card as $item) {
                $card_info = Card::find($item->id);
                $card_info->delete();
            }
        }
        $Column->delete();
        return response()->json([
            'message' => 'Column Deleted Successfully!!'
        ]);
    }
}
