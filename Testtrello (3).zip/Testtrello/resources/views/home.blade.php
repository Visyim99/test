@extends('layouts.app')

@section('content')


<div class="container">
    <Example-Component></Example-Component>
</div>
@endsection