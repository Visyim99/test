const Welcome = () => import('./components/ExampleComponent.vue' /* webpackChunkName: "resource/js/components/welcome" */)
const CategoryList = () => import('./components/ExampleComponent.vue' /* webpackChunkName: "resource/js/components/category/list" */)
// const CategoryCreate = () => import('./components/category/Add.vue' /* webpackChunkName: "resource/js/components/category/add" */)
// const CategoryEdit = () => import('./components/category/Edit.vue' /* webpackChunkName: "resource/js/components/category/edit" */)

export const routes = [
    {
        name: 'home',
        path: '/',
        component: Welcome
    },
    {
        name: 'categoryList',
        path: '/',
        component: CategoryList
    },
    // {
    //     name: 'categoryEdit',
    //     path: '/card',
    //     component: CategoryEdit
    // },
    // {
    //     name: 'categoryAdd',
    //     path: '/category/add',
    //     component: CategoryCreate
    // }
]