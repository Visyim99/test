<template>
    <div class="container">
        <div class="row">
            <form v-on:submit.prevent="create">
                <div class="col-12">
                    <input type="text" v-model="column.title" />

                    <button class="btn btn-primary">Save</button>
                </div>
                <br />
            </form>
        </div>

        <modal name="example" :width="300" :height="300" :adaptive="true">
            <form
                class="container"
                v-on:submit.prevent="
                    editstatus == false ? storeCard() : updatecard(card.card_id)
                "
            >
                <div class="form-group">
                    <label for="email">Title:</label>
                    <input
                        type="title"
                        class="form-control"
                        id="title"
                        v-model="card.title"
                    />
                </div>
                <div class="form-group">
                    <label for="pwd">Description:</label>
                    <input
                        type="description"
                        class="form-control"
                        id="description"
                        v-model="card.description"
                    />
                </div>

                <button class="btn btn-primary">Submit</button>
            </form>
        </modal>

        <div class="row">
            <div
                class="col-lg-4 col-md-6 col-sm-4"
                v-for="(item, key) in columnList"
                :key="key"
            >
                <div class="card">
                    <div class="card-header">
                        {{ item.title }}
                        <button
                            type="button"
                            @click="deleteColumn(item.id)"
                            class="float-right"
                        >
                            &times;
                        </button>
                    </div>
                    <button @click="addCard(item.id)">Add card</button>
                    <!-- <ul class="list-group list-group-flush">
                        <li class="list-group-item">Cras justo odio</li>
                        <li class="list-group-item">Dapibus ac facilisis in</li>
                        <li class="list-group-item">Vestibulum at eros</li>
                    </ul> -->

                    <draggable
                        class="drag-area"
                        :list="item.card"
                        :options="{ animation: 200, group: 'order' }"
                        :element="'article'"
                        @add="onAdd($event, item.id)"
                        @change="updateCardOrder(item)"
                    >
                        <article
                            class="card"
                            v-for="task in item.card"
                            :key="task.id"
                            :data-id="task.id"
                        >
                            <header class="text-center">
                                <span @click="editUpdate(task.id)">
                                    {{ task.title }}
                                </span>
                                <button
                                    type="button"
                                    @click="deleteCard(task.id)"
                                    class="float-right"
                                >
                                    &times;
                                </button>
                            </header>
                        </article>
                    </draggable>

                    <div class="card-body"></div>
                </div>
                <br />
            </div>
        </div>
    </div>
</template>

<script>
import draggable from "vuedraggable";

export default {
    components: {
        draggable,
    },
    data() {
        return {
            column: {
                title: "",
            },
            columnList: [],
            card: {
                title: "",
                description: "",
                column_id: "",
                card_id: "",
            },
            editstatus: false,
        };
    },
    mounted() {
        this.getColumnList();
    },
    methods: {
        create() {
            axios
                .post("/api/column", this.column)
                .then((response) => {
                    console.log(response);
                    this.getColumnList();
                    this.column = {
                        title: "",
                    };
                })
                .catch((error) => {
                    console.log(error);
                });
        },

        getColumnList() {
            axios
                .get("/api/column")
                .then((response) => {
                    console.log(response.data);
                    this.columnList = response.data;
                })
                .catch((error) => {
                    console.log(error);
                });
        },

        deleteColumn(id) {
            if (confirm("Are you sure to delete this column ?")) {
                axios
                    .delete(`/api/column/${id}`)
                    .then((response) => {
                        this.getColumnList();
                    })
                    .catch((error) => {
                        console.log(error);
                    });
            }
        },

        addCard(id) {
            this.card = {
                title: "",
                description: "",
            };
            this.editstatus = false;
            this.$modal.show("example");
            this.card.column_id = id;
        },

        editUpdate(id) {
            axios
                .post(`/api/card/edit/${id}`)
                .then((response) => {
                    console.log("add card ", response);
                    this.card = {
                        title: response.data.card.title,
                        description: response.data.card.description,
                        card_id: response.data.card.id,
                    };
                    this.editstatus = true;
                    this.$modal.show("example");
                })
                .catch((error) => {
                    console.log(error);
                });
        },

        updatecard(id) {
            axios
                .post(`/api/card/update/${id}`, this.card)
                .then((response) => {
                    console.log("add card ", response);
                    this.card = {
                        title: response.data.card.title,
                        description: response.data.card.description,
                    };
                    this.editstatus = false;
                    this.$modal.hide("example");
                    this.getColumnList();
                })
                .catch((error) => {
                    console.log(error);
                });
        },

        deleteCard(id) {
            if (confirm("Are you sure to delete this card ?")) {
                axios
                    .delete(`/api/card/delete/${id}`)
                    .then((response) => {
                        this.getColumnList();
                    })
                    .catch((error) => {
                        console.log(error);
                    });
            }
        },

        storeCard() {
            axios
                .post(`/api/card`, this.card)
                .then((response) => {
                    console.log("add card ", response);
                    this.$modal.hide("example");
                    this.card = {
                        title: "",
                        description: "",
                    };
                    this.getColumnList();
                })
                .catch((error) => {
                    console.log(error);
                });
        },

        onAdd(event, column_id) {
            let id = event.item.getAttribute("data-id");
            axios
                .post(`/api/card/addcardColumn`, {
                    column_id: column_id,
                    id: id,
                })
                .then((response) => {
                    console.log(response.data);
                })
                .catch((error) => {
                    console.log(error);
                });
        },

        updateCardOrder(item) {
            item.card.map((card, index) => {
                card.order = index + 1;
            });

            axios
                .post(`/api/card/updateAll`, { cards: item.card })
                .then((response) => {
                    console.log(response.data);
                })
                .catch((error) => {
                    console.log(error);
                });
        },
    },
};
</script>
<style>
.list {
    background-color: #26004d;
    border-radius: 3px;
    margin: 5px 5px;
    padding: 10px;
    width: 100%;
}
.list > header {
    font-weight: bold;
    color: white;
    text-align: center;
    font-size: 20px;
    line-height: 28px;
    cursor: grab;
}
.list article {
    border-radius: 3px;
    margin-top: 10px;
}

.list .card {
    background-color: #fff;
    border-bottom: 1px solid #ccc;
    padding: 15px 10px;
    cursor: pointer;
    font-size: 16px;
    font-weight: bolder;
}
.list .card:hover {
    background-color: #f0f0f0;
}
.drag-area {
    min-height: 10px;
}
</style>
